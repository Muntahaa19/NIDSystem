# Network Intrusion Detection System (NIDS)

This project is a real-time NIDS that uses machine learning to detect network attacks.

## 📁 Project Structure
```
nids_project/
├── backend/
│   ├── app.py
│   ├── utils.py
│   └── model.pkl (Generated)
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── dataset/
│   └── Train_data.csv
└── README.md
```

## 🔧 Setup Instructions

1. Install dependencies:
```bash
pip install flask pandas scikit-learn joblib
```

2. Place `model.pkl` and `encoders.pkl` in the `backend/` directory.

3. Run the Flask server:
```bash
cd backend
python app.py
```

4. Open [http://127.0.0.1:5000](http://127.0.0.1:5000) in your browser to see the dashboard.

## 🚨 Live Alerts
The dashboard updates every 3 seconds with the latest detected attacks.

## 📡 Simulated Input
You can POST data to `/predict` with JSON to simulate network activity.